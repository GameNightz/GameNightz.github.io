<?php

namespace App\Entity;

use App\Repository\UserRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: UserRepository::class)]
class User
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $email = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $role = null;

    #[ORM\Column(length: 255)]
    private ?string $password = null;

    #[ORM\Column(length: 255)]
    private ?string $userName = null;

    #[ORM\Column(length: 255)]
    private ?string $firstName = null;

    #[ORM\Column(length: 255)]
    private ?string $lastName = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $dateOfBirth = null;

    #[ORM\ManyToMany(targetEntity: Game::class, mappedBy: 'likedBy')]
    private Collection $preferredGames;

    #[ORM\ManyToMany(targetEntity: gameNight::class, inversedBy: 'visitors')]
    private Collection $attends;

    public function __construct()
    {
        $this->preferredGames = new ArrayCollection();
        $this->attends = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): static
    {
        $this->email = $email;

        return $this;
    }

    public function getRole(): ?string
    {
        return $this->role;
    }

    public function setRole(?string $role): static
    {
        $this->role = $role;

        return $this;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(string $password): static
    {
        $this->password = $password;

        return $this;
    }

    public function getUserName(): ?string
    {
        return $this->userName;
    }

    public function setUserName(string $userName): static
    {
        $this->userName = $userName;

        return $this;
    }

    public function getFirstName(): ?string
    {
        return $this->firstName;
    }

    public function setFirstName(string $firstName): static
    {
        $this->firstName = $firstName;

        return $this;
    }

    public function getLastName(): ?string
    {
        return $this->lastName;
    }

    public function setLastName(string $lastName): static
    {
        $this->lastName = $lastName;

        return $this;
    }

    public function getDateOfBirth(): ?\DateTimeInterface
    {
        return $this->dateOfBirth;
    }

    public function setDateOfBirth(\DateTimeInterface $dateOfBirth): static
    {
        $this->dateOfBirth = $dateOfBirth;

        return $this;
    }

    /**
     * @return Collection<int, Game>
     */
    public function getPreferredGames(): Collection
    {
        return $this->preferredGames;
    }

    public function addPreferredGame(Game $preferredGame): static
    {
        if (!$this->preferredGames->contains($preferredGame)) {
            $this->preferredGames->add($preferredGame);
            $preferredGame->addLikedBy($this);
        }

        return $this;
    }

    public function removePreferredGame(Game $preferredGame): static
    {
        if ($this->preferredGames->removeElement($preferredGame)) {
            $preferredGame->removeLikedBy($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, gameNight>
     */
    public function getAttends(): Collection
    {
        return $this->attends;
    }

    public function addAttend(gameNight $attend): static
    {
        if (!$this->attends->contains($attend)) {
            $this->attends->add($attend);
        }

        return $this;
    }

    public function removeAttend(gameNight $attend): static
    {
        $this->attends->removeElement($attend);

        return $this;
    }
}
